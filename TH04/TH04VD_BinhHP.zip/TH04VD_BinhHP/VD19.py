import numpy as np

array_eye = np.eye(5) 

print(array_eye)
print("Kiểu dữ liệu của phẩn tử trong mảng array_eye: ", array_eye.dtype)
print("Kích thước của mảng array_eye: ", array_eye.shape)
print("Số phần tử của mảng array_eye: ",array_eye.size)
print("Số chiều của mảng array_eye: ", array_eye.ndim)