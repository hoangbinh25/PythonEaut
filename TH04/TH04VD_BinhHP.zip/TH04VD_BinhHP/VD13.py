import numpy as np

a = np.array([1, 2, 5, 7, 0, 8])

print(a)
print("Loại dữ liệu của biến a: ", type(a))
print("Kiểu dữ liệu của phẩn tử trong mảng a: ", a.dtype)
print("Kích thước của mảng a: ", a.shape)
print("Số phần tử của mảng a: ", a.size)
print("Số chiều của mảng a: ", a.ndim)
