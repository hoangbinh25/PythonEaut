import numpy as np

d = np.arange(1, 15, 2)
print('Vector: d', d)
print('Số phần tử của vector d: ', d.size)

print('----------------------------------------------------------------')

f = np.linspace(1, 15, 11)
print('Vector f: ', f)
print('Số phần tử của vector f: ', f.size)