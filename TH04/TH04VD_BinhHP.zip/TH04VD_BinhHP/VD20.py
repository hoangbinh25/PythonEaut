import numpy as np

array_random = np.random.random((7, 5)) 

print(array_random)
print("Kiểu dữ liệu của phẩn tử trong mảng array_random: ", array_random.dtype)
print("Kích thước của mảng array_random: ", array_random.shape)
print("Số phần tử của mảng array_random: ",array_random.size)
print("Số chiều của mảng array_random: ", array_random.ndim)