import numpy as np

array_rand = np.random.randint(10, 30, 6)

print(array_rand)