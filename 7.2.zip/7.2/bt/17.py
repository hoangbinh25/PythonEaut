import pandas as pd

# Đọc file CSV (giả sử bạn đã lưu file csv_Data_Loan.csv trên máy)
df = pd.read_csv(r"D:\PHYTHON\7.2\bt\data-demo-2.csv")

# Hiển thị dữ liệu
print(df)