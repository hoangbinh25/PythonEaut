fo = open('data.txt', 'w')

fo.write('Tobe or not tobe. \n Nghi lon de thanh cong ! \n')

fo.close()
print("Ghi file thanh cong")