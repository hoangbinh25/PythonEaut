f2 = open('Ghifile.txt')

print('1. Tên file: ', f2.name)
print('2. Chế độ mở file: ', f2.mode)
print('3. Trạng thái đóng file: ', f2.closed)
