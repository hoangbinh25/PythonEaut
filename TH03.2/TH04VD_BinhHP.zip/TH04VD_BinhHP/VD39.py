
f1 = open('Ghifile.txt', 'w')

st = 'Welcome to Python for Analysis!'

f1.write(st)
f1.close()